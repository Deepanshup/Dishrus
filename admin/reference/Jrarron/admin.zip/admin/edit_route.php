<!DOCTYPE html>
<html lang="en" class="no-js"> 
    <head>
        <style>
            p.poi {
               height: 100;
            }
        </style>
        <meta charset="UTF-8" />
        <title>Jrarron | Edit Route</title>
        <link rel="icon" sizes="72x72" href="./images/logo.png">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCdFvXTNcn2V80lPvfSMEl1FuLegxJJNos&libraries=places" type="text/javascript"></script>
		<script type="text/javascript">
               function initialize() {
                    var input = document.getElementById('source');
                    var autocompletess = new google.maps.places.Autocomplete(input);
                    var inputs = document.getElementById('destination');
                    var autocompletes = new google.maps.places.Autocomplete(inputs);
               }
               google.maps.event.addDomListener(window, 'load', initialize);
       </script>
    </head>
    <body>
    <?php
    session_start();
    $servername = "localhost";
    $username = "nadaa93i_gaurav";
    $password = "root@123";
    $dbname = "nadaa93i_Jrarron";
    try 
    {   $message="";
        $conn = new mysqli($servername, $username, $password,$dbname);
        $end=$_SESSION["end"];
        if($end!="true"){
            echo '<script>
                    window.location="adminLogin.php";
                </script>';
        }
        $pl=$_SESSION['place'] ;
        $cat=$_SESSION['category'];
        $imgn=$_SESSION['image_name'];
        $abt=$_SESSION['about'] ;
        $poi=$_SESSION['poi'];
        $ID=$_SESSION['ID'];
        $source=$_SESSION['source'];
        $destination=$_SESSION['destination'];
        $POIAUDIO=$_SESSION['poiAudio'];
        $POIAUDIOEXPLODED=explode('|', $POIAUDIO);
        $poii=explode('|', $poi);

        if(isset($_POST["register"])){
            $route_name=$_POST["passwordsignup"];
            $sourceNew=$_POST["source"];
            $i=0;
            $destinationNew=$_POST["destination"];
            $about_route=$_POST["passwordsignup_confirm"];
            if($_POST["poi"]!=""){
                $poi=$_POST["poi"];
                
                    $stripped = str_replace(' ', '', $_POST["poi"]);
                    $target_dirPOI = "poi/";
                    $target_filePOI = $target_dirPOI.$route_id.$stripped.basename($_FILES["poiAudio"]["name"]);
                    if (move_uploaded_file($_FILES["poiAudio"]["tmp_name"], $target_filePOI)) {
                        $imagesPOI=$route_id.$stripped.basename( $_FILES["poiAudio"]["name"],".jpg"); 
                        $actualpathPOI = "https://bazar4you.online/gaurav/Jrarron/admin/poi/$imagesPOI";
                    } 
                    else {
                        $message="Sorry, there was an error uploading your file.";
                    }
                
                
                
                
                $i++;
            }
            for ($num = 1; $num <= 9; $num ++) { 
                $temp='poi'.$num;
                if($_POST[$temp]!=""){
                    $poi=$poi.'|'.$_POST[$temp];
                    
                    
                    $stripped = str_replace(' ', '', $_POST[$temp]);
                    $target_dirPOI = "poi/";
                    $target_filePOI = $target_dirPOI.$route_id.$stripped.basename($_FILES["poiAudio".$num]["name"]);
                    if (move_uploaded_file($_FILES["poiAudio".$num]["tmp_name"], $target_filePOI)) {
                        $imagesPOI=$route_id.$stripped.basename( $_FILES["poiAudio".$num]["name"],".jpg"); 
                        $actualpathPOI = $actualpathPOI.'|'."https://bazar4you.online/gaurav/Jrarron/admin/poi/$imagesPOI";
                    } 
                    else {
                        $message="Sorry, there was an error uploading your file.";
                    }
                    
                    
                    
                    
                    
                    
                    $i++;
                }
            }
		    if(isset($_FILES['imageUpload']) && !empty($_FILES['imageUpload']['name'])){
		        $target_dir = "uploads/";
                $target_file = $target_dir . $cat.$route_name.basename($_FILES["imageUpload"]["name"]);
                $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		        if(isset($_FILES['poiAudio']) && !empty($_FILES['poiAudio']['name'])){
		            $target_dirPOI = "poi/";
                    $target_filePOI = $target_dirPOI . $cat.$route_name. basename($_FILES["poiAudio"]["name"]);
                    if (move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file) && move_uploaded_file($_FILES["poiAudio"]["tmp_name"], $target_filePOI)) {
                        $images= $cat.$route_name.basename( $_FILES["imageUpload"]["name"],".jpg"); 
                        $actualpath = "https://bazar4you.online/gaurav/Jrarron/admin/uploads/$images";
                        $imagesPOI=$cat.$route_name.basename( $_FILES["poiAudio"]["name"],".jpg"); 
                        $actualpathPOI = "https://bazar4you.online/gaurav/Jrarron/admin/poi/$imagesPOI";
                                try {
                                    $con = new mysqli($servername, $username, $password,$dbname);
                                    $sql = "UPDATE `admin` SET place='$route_name' `rating`='0',`img_name`='$images',`img_url`='$actualpath',
                                            `about_route`='$about_route',`point_of_interest`='$poi',`poi_audio_file`='$target_filePOI',`source`='$sourceNew',`destination`='$destinationNew' WHERE category='$cat' and route_id='$ID' ";
                                    $_SESSION["end"]="true";
                                    if ($conn->query($sql)) {
                                        $message="Route successfully Updated.";
                                    } 
                                    else 
                                    {
                                        $message="Error while Updating1";
                                    }
                                }
                                catch(PDOException $e)
                                {
                                    $message="Error in Network";
                                    $_SESSION["end"]="false";

                                }
                    } 
                    else {
                        $message="Sorry, there was an error uploading your file.";
                    }
		        }
                else{
                    if (move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file) ) {
                        $images= $cat.$route_name.basename( $_FILES["imageUpload"]["name"],".jpg"); 
                        $actualpath = "https://bazar4you.online/gaurav/Jrarron/admin/uploads/$images";
                                try {
                                    $con = new mysqli($servername, $username, $password,$dbname);
                                    $sql = "UPDATE `admin` SET place='$route_name' `rating`='0',`img_name`='$images',`img_url`='$actualpath',
                                            `about_route`='$about_route',`point_of_interest`='$poi',`source`='$sourceNew',`destination`='$destinationNew' WHERE category='$cat' and route_id='$ID' ";
                                    $_SESSION["end"]="true";
                                    if ($conn->query($sql)) {
                                        $message="Route successfully Updated.";
                                    } 
                                    else 
                                    {
                                        $message="Error while Updating2";
                                    }
                                }
                                catch(PDOException $e)
                                {
                                    $message="Error in Network";
                                    $_SESSION["end"]="false";
                                }
                    } 
                    else {
                        $message="Sorry, there was an error uploading your file.";
                    }
                }
		    }
            else{
                try {
                        $con = new mysqli($servername, $username, $password,$dbname);
                        $sql = "UPDATE `admin` SET place='$route_name' ,`rating`='0',
                                    `about_route`='$about_route',`point_of_interest`='$poi',`source`='$sourceNew',`destination`='$destinationNew' WHERE category='$cat' and route_id='$ID' ";
                        $_SESSION["end"]="true";
                        if ($conn->query($sql)) {
                               $message="Route successfully Updated.";
                        } 
                        else 
                        {
                                $message="Error while Updating3";
                        }
                    }
                    catch(PDOException $e)
                    {
                        $message="Error in Network";
                        $_SESSION["end"]="false";
                    }
            }
        }
        }
        catch(PDOException $e)
        {
        }
    ?>
        <div class="container">
            <header>
				<nav class="codrops-demos">
				</nav>
            </header>
            <section>				
                <div id="container_demo" >
                    <div id="wrapper">

                        <div id="login" class="animate form">
                            <form  action="" method="post" autocomplete="on" enctype="multipart/form-data"> 
                                <h1> Edit Route </h1> 
                                <p> 
                                    <label for="usernamesignup" class="uname"  > Category </label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="text" value="<?=$cat?>" placeholder="<?=$cat?>" readonly/>
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" >Route Name</label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="text" value="<?=$pl?>" placeholder="<?=$pl?>" />
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Source</label>
                                    <input id="source" name="source" required="required" type="text" maxlength="100" value="<?=$source?>"  placeholder="eg. Berclona"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Destination</label>
                                    <input id="destination" name="destination" required="required" type="text" maxlength="100" value="<?=$destination?>"  placeholder="eg. Berclona"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >About Route</label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="text" value="<?=$abt?>" placeholder="<?=$abt?>"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Point of Interest</label>
                                    <label for="passwordsignup_confirm" class="youpasswd" onclick="myFunction('poi')" style="  margin-left: 280px;font-size: 10px;">+Add</label>
                                    <input id="poi" name="poi"  type="text" value="<?=$poii[0]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[0]?>" />
                                    </audio>
                                    <label id="b" onclick="myFunctionn('b','poi','poiAudio')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi1" name="poi1"  type="text" value="<?=$poii[1]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio1" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[1]?>" />
                                    </audio>
                                    <label id="b1" onclick="myFunctionn('b1','poi1','poiAudio1')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi2" name="poi2"  type="text" value="<?=$poii[2]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio2" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[2]?>" />
                                    </audio>
                                    <label id="b2" onclick="myFunctionn('b2','poi2','poiAudio2')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi3" name="poi3"  type="text" value="<?=$poii[3]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio3" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[3]?>" />
                                    </audio>
                                    <label id="b3" onclick="myFunctionn('b3','poi3','poiAudio3')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi4" name="poi4"  type="text" value="<?=$poii[4]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio4"  controls>
                                        <source src="<?=$POIAUDIOEXPLODED[4]?>" />
                                    </audio>
                                    <label id="b4" onclick="myFunctionn('b4','poi4','poiAudio4')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi5" name="poi5"  type="text" value="<?=$poii[5]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio5" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[5]?>" />
                                    </audio>
                                    <label id="b5" onclick="myFunctionn('b5','poi5','poiAudio5')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi6" name="poi6"  type="text" value="<?=$poii[6]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio6" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[6]?>" />
                                    </audio>
                                    <label id="b6" onclick="myFunctionn('b6','poi6','poiAudio6')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi7" name="poi7" type="text" value="<?=$poii[7]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio7" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[7]?>" />
                                    </audio>
                                    <label id="b7" onclick="myFunctionn('b7','poi7','poiAudio7')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi8" name="poi8"  type="text" value="<?=$poii[8]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio8" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[8]?>" />
                                    </audio>
                                    <label id="b8" onclick="myFunctionn('b8','poi8','poiAudio8')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <input id="poi9" name="poi9" type="text" value="<?=$poii[9]?>" placeholder="eg.Sagrada Famili "/>
                                    <audio id="poiAudio9" controls>
                                        <source src="<?=$POIAUDIOEXPLODED[9]?>" />
                                    </audio>
                                    <label id="b9" onclick="myFunctionn('b9','poi9','poiAudio9')" style="  margin-left: 380px;font-size: 10px;">.remove</label>
                                    
                                    <script>
                                        var i='';
                                        var j;
                                        var y;
                                        if(document.getElementById('poi')==''){
                                            y = document.getElementById('poi');
                                            y.style.display = "none";
                                            y = document.getElementById('b');
                                            y.style.display = "none";
                                            y = document.getElementById('poiAudio');
                                            y.style.display = "none";
                                            i=1;
                                        }
                                        for (j = 1; j < 10; j++) { 
                                            y = document.getElementById('poi'+j);
                                            if(y.value==''){
                                                y.style.display = "none";
                                                var q = document.getElementById('b'+j);
                                                var ss = document.getElementById('poiAudio'+j);
                                                q.style.display = "none";
                                                ss.style.display = "none";
                                            }
                                            else{
                                                i++;
                                            }
                                        }
                                        function myFunction(id) {
                                            var x = document.getElementById(id+i);
                                            x.style.display = "block";
                                            var z = document.getElementById('b'+i);
                                            z.style.display = "block";
                                            z = document.getElementById('poiAudio'+i);
                                            z.style.display = "block";
                                          i++;

                                        }
                                        function myFunctionn(id,idd,poiAudio) {
                                            var x = document.getElementById(id);
                                            x.style.display = "none";
                                            var z = document.getElementById(idd);
                                                    document.getElementById(idd).value = "";
                                            z.style.display = "none";
                                            z = document.getElementById(poiAudio);
                                            z.style.display = "none";
                                              var res = id.substring(1, 2);
                                            i='';
                                        }
                                        function initt() {
                                            var In = [];
                                            var autocomplete = [];
                                            In[0] = document.getElementById('poi');
                                            autocomplete[0] = new google.maps.places.Autocomplete(In[0]);
                                            
                                            In[1] = document.getElementById('poi1');
                                            autocomplete[1] = new google.maps.places.Autocomplete(In[1]);
                                            
                                            In[2] = document.getElementById('poi2');
                                            autocomplete[2] = new google.maps.places.Autocomplete(In[2]);
                                            
                                            In[3] = document.getElementById('poi3');
                                            autocomplete[3] = new google.maps.places.Autocomplete(In[3]);
                                            
                                            In[4] = document.getElementById('poi4');
                                            autocomplete[4] = new google.maps.places.Autocomplete(In[4]);
                                            
                                            In[5] = document.getElementById('poi5');
                                            autocomplete[5] = new google.maps.places.Autocomplete(In[5]);
                                            
                                            In[6] = document.getElementById('poi6');
                                            autocomplete[6] = new google.maps.places.Autocomplete(In[6]);
                                            
                                            In[7] = document.getElementById('poi7');
                                            autocomplete[7] = new google.maps.places.Autocomplete(In[7]);
                                            
                                            In[8] = document.getElementById('poi8');
                                            autocomplete[8] = new google.maps.places.Autocomplete(In[8]);
                                            
                                            In[9] = document.getElementById('poi9');
                                            autocomplete[9] = new google.maps.places.Autocomplete(In[9]);
                                        }
                                        google.maps.event.addDomListener(window, 'load', initt);
                                    </script>                                    
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" >Image</label>
                                    <input  type="file" id="imageUpload" name="imageUpload" class="to_register"  />
                                </p>
                                <p class="signin button"> 
									<input type="submit" name="register" value="Done"/> 
								</p>
								<p class="uname">
                                    <?=$message?>
                                </p>
                                <p class="change_link">  
									Don't want to edit  route ?
									<a href="tables.php" class="to_register"> Go to Tables view </a>
								</p>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </body>
